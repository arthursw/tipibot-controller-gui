# Installation
> `npm install --save @types/file-saver`

# Summary
This package contains type definitions for FileSaver.js (https://github.com/eligrey/FileSaver.js/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/file-saver

Additional Details
 * Last updated: Wed, 26 Apr 2017 18:47:06 GMT
 * Dependencies: none
 * Global values: saveAs

# Credits
These definitions were written by Cyril Schumacher <https://github.com/cyrilschumacher>, Daniel Roth <https://github.com/DaIgeb>.
