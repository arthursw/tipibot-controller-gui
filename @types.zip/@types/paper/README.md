# Installation
> `npm install --save @types/paper`

# Summary
This package contains type definitions for Paper.js (http://paperjs.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/paper

Additional Details
 * Last updated: Fri, 10 Mar 2017 06:58:03 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Clark Stevenson <http://github.com/clark-stevenson>.
