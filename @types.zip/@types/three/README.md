# Installation
> `npm install --save @types/three`

# Summary
This package contains type definitions for three.js r81 (http://mrdoob.github.com/three.js/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/three

Additional Details
 * Last updated: Fri, 16 Dec 2016 16:24:57 GMT
 * Library Dependencies: webvr-api
 * Module Dependencies: none
 * Global values: Detector, THREE

# Credits
These definitions were written by Kon <http://phyzkit.net/>, Satoru Kimura <https://github.com/gyohk>, Florent Poujol <https://github.com/florentpoujol>, SereznoKot <https://github.com/SereznoKot>.
