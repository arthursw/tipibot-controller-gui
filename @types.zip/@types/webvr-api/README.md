# Installation
> `npm install --save @types/webvr-api`

# Summary
This package contains type definitions for WebVR API (https://w3c.github.io/webvr/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/webvr-api

Additional Details
 * Last updated: Wed, 28 Dec 2016 21:10:59 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: VRDisplay, VRFrameData

# Credits
These definitions were written by six a <https://github.com/lostfictions>.
