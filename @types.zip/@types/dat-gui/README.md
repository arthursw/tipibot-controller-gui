# Installation
> `npm install --save @types/dat-gui`

# Summary
This package contains type definitions for dat.GUI (https://github.com/dataarts/dat.gui).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/dat-gui

Additional Details
 * Last updated: Sat, 07 Jan 2017 15:53:48 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: dat

# Credits
These definitions were written by Satoru Kimura <https://github.com/gyohk>, ZongJing Lu <https://github.com/sonic3d>.
